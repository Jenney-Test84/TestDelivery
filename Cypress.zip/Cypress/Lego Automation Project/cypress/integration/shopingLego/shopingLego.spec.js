import { Given, When, Then } from "cypress-cucumber-preprocessor/steps";
import HomePage from '../../support/PageObject/HomePage'

const homePage = new HomePage()


Given("I load site web Lego", () => {
    cy.visit('https://www.lego.com/es-es')
    cy.wait(10000)

})
When('I search select the product add to the basket', () => {
    homePage.getInitButton().click()
    homePage.getAcceptCookiesButton().contains("Aceptar todo").click({ force: true })
    homePage.getOpenSearchBox().click()
    homePage.getSearchBox().click().type('star wars BB-8').type('{enter}', 'waitForAnimations')
    homePage.getOpenSearchBox().click()
    homePage.getSearchInputSecond().click().type('calle').each(($el, index, $list) => {
        homePage.getProductBox().eq(index).then(function ($el1) {
            let precio = $el1.text()
            cy.log('el precio es.' + precio).click()

        })
        Then('purchase product', () => {
            homePage.getAddproductButton().click()
            homePage.getMessageHeader().click().then(function ($el2) {
                let messagge = $el2.text()
                assert.isOk(messagge, 'Añadido a la bolsa')

            })




        })
    })
})