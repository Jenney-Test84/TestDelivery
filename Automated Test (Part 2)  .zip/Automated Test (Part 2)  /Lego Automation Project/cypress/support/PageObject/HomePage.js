class HomePage 
{
  
  getInitButton(){return cy.get('[data-test=age-gate-grown-up-cta]')}
  getAcceptCookiesButton(){return cy.get(' div.CookieModalstyles__CookieActions-sc-19wlthm-7.hqvBpc > button.Button__Base-sc-1jdmsyi-0.aKFCv.CookieModalstyles__PrimaryButton-sc-19wlthm-8.kEKtzq')}
  getOpenSearchBox(){return cy.get('.Searchstyles__SearchIcon-qaapd1-6')}
  getSearchBox(){return cy.get('#mobile-main-search-search-input')}
  getInteraction(){return cy.get('.Searchstyles__SearchIcon-qaapd1-6 > path')}
  getSearchInputSecond(){return cy.get('#mobile-main-search-search-input')}
  getProductBox(){return cy.get('body #mobile-main-search-search-suggestions').as('ProductList').find('[data-test=product-suggestion-price]')}
  getProductSugestion(){return cy.get('#desktop-search-search-suggestions > li.Suggestionsstyles__ListItem-sc-23m0k9-2.fOzxNK > a > div')}
  getAddproductButton(){return cy.get('button[data-test=add-to-bag]')}
  getMessageHeader(){return cy.get('[data-test=add-to-bag] > .ButtonLabelWithProgressstyles__StyledMessage-sc-19upyqe-1')}
}
export default HomePage;